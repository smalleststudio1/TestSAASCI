package 'git' do
  action :install
end
